module.exports = {
    FB_PAGE_TOKEN: '',
    FB_VERIFY_TOKEN: '',
    API_AI_CLIENT_ACCESS_TOKEN: '',
    FB_APP_SECRET: '',
    SERVER_URL: "",
    SENGRID_API_KEY: '',
    EMAIL_FROM: '',
    EMAIL_TO: '',
    WEATHER_API_KEY: '',
};